typedef long long int lli;

extern lli comp;
extern lli atrib;

struct Node{
	int key;
	std::string info;
};

